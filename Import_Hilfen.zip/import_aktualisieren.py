"""CSV aktualisieren, historische Ergebnisse abgleichen, manuelle Nachträge erhalten.

python3 import_aktualisieren.py StatFormImport.csv Soz_Auswertung.xlsx
Optional: --referenz Pfad/Referenz.xlsm
Benötigt Python 3 und openpyxl; für verschlüsselte Ausgaben zusätzlich
msoffcrypto-tool. Das Öffnungspasswort wird verdeckt abgefragt und beim
Aktualisieren beibehalten. Führt keine Excel-Makros aus.
"""
import argparse
import csv
import getpass
import hashlib
import io
import json
import math
import os
import re
import tempfile
from collections import Counter, defaultdict
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font

NOTE_HEADERS = [
    'Datensatz_ID', 'Fallnummer', 'Originaltext_K', 'Originaltext_L',
    'Nachtrag_K', 'Nachtrag_L', 'Bearbeitungsstatus', 'Notiz', 'Im_aktuellen_Import',
]
REFERENCE_HEADERS = ['Ergebnis_Referenz_G', 'Referenz_Status', 'Referenz_Quelle']
IMPORT_HEADERS = [
    'Datensatz_ID', 'Manuelle_Nachbearbeitung', 'Grund_Nachbearbeitung',
    *REFERENCE_HEADERS, 'Text_K_mit_Nachtrag', 'Ueberleitung_L_mit_Nachtrag',
    'Bearbeitungsstatus', 'Notiz', 'Text_K_Original', 'Ueberleitung_L_Original',
    'Textquelle_K', 'Textquelle_L',
]


def present(value):
    return value is not None and bool(str(value).strip())


def validate_strings(values):
    # openpyxl kürzt bei der Zellzuweisung selbstständig; vorher prüfen.
    if any(isinstance(value, str) and len(value) > 32767 for value in values):
        raise ValueError('Text überschreitet die Excel-Zellgrenze; keine Daten werden gekürzt.')


def case_id(value):
    """Excel-Zahlen und CSV-Zeichenketten abgleichen; keine Namenssuche."""
    if value is None or isinstance(value, bool):
        return ''
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            return ''
        return str(int(value))
    value = str(value).strip()
    if re.fullmatch(r'[0-9]+(?:\.0+)?', value):
        return str(int(value.split('.')[0]))
    return value


def key(row):
    # Bestehende IDs beibehalten: Fallnummer und exaktes ursprüngliches Textpaar.
    return hashlib.sha256(json.dumps([row[0], row[10], row[11]], ensure_ascii=False).encode()).hexdigest()


def reference_path(source, explicit=None):
    if explicit is not None:
        p = Path(explicit)
        if not p.is_file():
            raise FileNotFoundError('Die ausdrücklich gewählte Referenzdatei fehlt.')
        return p
    folder = Path(source).resolve().parent
    for name in ['StatBoardReakt_Neu.xlsm', 'Statistik_Container_2026.xlsm']:
        p = folder / name
        if p.is_file():
            return p
    return None


def read_reference(path):
    results = defaultdict(list)
    if path is None:
        return results
    wb = load_workbook(path, read_only=True, data_only=True)
    formulas = load_workbook(path, read_only=True, data_only=False)
    supported = 0
    try:
        for sheet in wb:
            header_row = id_col = None
            for number, row in enumerate(sheet.iter_rows(min_row=1, max_row=min(20, sheet.max_row), values_only=True), 1):
                if len(row) < 7 or str(row[6] or '').strip().casefold() != 'ergebnis':
                    continue
                columns = [i for i, v in enumerate(row) if str(v or '').strip().casefold().replace(' ', '').rstrip('.') in {'fallnummer', 'fallnr'}]
                if len(columns) == 1:
                    header_row, id_col = number, columns[0]
                    break
            if header_row is None:
                continue
            supported += 1
            source_rows = formulas[sheet.title].iter_rows(min_row=header_row + 1, values_only=True)
            for number, (row, formula_row) in enumerate(zip(sheet.iter_rows(min_row=header_row + 1, values_only=True), source_rows), header_row + 1):
                ident = case_id(row[id_col])
                # Platzhalter wie 'unbekannt' sind keine Krankenhaus-Fallnummern.
                if not ident.isdigit():
                    continue
                value = row[6]
                uncached = isinstance(formula_row[6], str) and formula_row[6].startswith('=') and not present(value)
                if present(value) or uncached:
                    results[ident].append({
                        'text': str(value).strip() if present(value) else '',
                        'source': f'{path.name} / {sheet.title}!G{number}',
                        'uncached': uncached,
                    })
        if not supported:
            raise ValueError('Referenz enthält kein Blatt mit Fallnummer und Ergebnis in Spalte G. Datei bleibt unverändert.')
    finally:
        wb.close()
        formulas.close()
    return results


def reference_info(row, results, path):
    if all(present(row[i]) for i in [10, 11]):
        return '', 'Nicht benötigt', ''
    if path is None:
        return '', 'Referenzdatei fehlt', ''
    hits = results.get(case_id(row[0]), [])
    texts = list(dict.fromkeys(h['text'] for h in hits if h['text']))
    sources = '\n'.join(h['source'] for h in hits)
    if any(h['uncached'] for h in hits):
        status = 'Formelergebnis fehlt – Referenz in Excel neu berechnen'
    elif len(texts) > 1:
        status = 'Mehrere unterschiedliche Ergebnisse – prüfen'
    elif texts:
        status = 'Treffer'
    else:
        status = 'Kein Ergebnis gefunden'
    info = ('\n'.join(texts), status, sources)
    validate_strings(info)
    return info


def update(source, target, reference=None, password=None):
    source, target = Path(source), Path(target)
    if target.suffix.lower() != '.xlsx':
        raise ValueError('Ausgabedatei muss .xlsx sein; Referenzmakros werden nicht verändert.')
    ref = reference_path(source, reference)
    if target.resolve() == source.resolve() or (ref and target.resolve() == ref.resolve()):
        raise ValueError('Ausgabe darf keine Eingabedatei überschreiben.')
    raw = source.read_bytes()
    try:
        text = raw.decode('utf-8-sig')
    except UnicodeDecodeError:
        text = raw.decode('cp1252')
    rows = list(csv.reader(io.StringIO(text, newline=''), delimiter=';'))
    for row in rows:
        validate_strings(row)
    if not rows or len(rows[0]) < 14 or rows[0][13] != 'GewuenschteUntersuchung':
        raise ValueError('Erwartete Spalte N GewuenschteUntersuchung fehlt.')
    selected, filtered = {}, 0
    for number, row in enumerate(rows[1:], 2):
        if not row or all(not present(v) for v in row):
            continue
        if len(row) != len(rows[0]):
            raise ValueError(f'CSV-Zeile {number}: Spaltenzahl passt nicht zum Kopf.')
        if row[13] in {'FSSOZKN2', 'FSSOZKN3'}:
            if not present(row[0]):
                raise ValueError(f'CSV-Zeile {number}: Fallnummer fehlt, Zuordnung nicht sicher möglich.')
            filtered += 1
            selected.setdefault(key(row), row)
    reference_results = read_reference(ref)
    encrypted_input = False
    office_crypto = None
    if target.exists():
        with target.open('rb') as existing_file:
            encrypted_input = existing_file.read(8) == b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1'
        if encrypted_input:
            try:
                import msoffcrypto as office_crypto
            except ImportError as exc:
                raise RuntimeError(
                    'Für passwortgeschützte Excel-Dateien fehlt msoffcrypto-tool. '
                    'Bitte installieren: python -m pip install msoffcrypto-tool'
                ) from exc
            if password is None:
                password = getpass.getpass('Öffnungspasswort der Excel-Datei: ')
            if not password:
                raise ValueError('Ein Öffnungspasswort ist erforderlich; die Datei bleibt unverändert.')
            plaintext = io.BytesIO()
            with target.open('rb') as existing_file:
                encrypted_file = office_crypto.OfficeFile(existing_file)
                if not encrypted_file.is_encrypted():
                    raise ValueError('Ausgabedatei ist keine unterstützte verschlüsselte XLSX-Datei.')
                encrypted_file.load_key(password=password, verify_password=True)
                encrypted_file.decrypt(plaintext, verify_integrity=True)
            plaintext.seek(0)
            wb = load_workbook(plaintext)
        else:
            wb = load_workbook(target)
    else:
        wb = Workbook()
    if not target.exists():
        wb.remove(wb.active)
    if 'Manueller Nachtrag' not in wb:
        notes = wb.create_sheet('Manueller Nachtrag')
        notes.append(NOTE_HEADERS + REFERENCE_HEADERS)
    notes = wb['Manueller Nachtrag']
    if [notes.cell(1, i).value for i in range(1, 10)] != NOTE_HEADERS:
        raise ValueError('Spalten im Blatt Manueller Nachtrag wurden verändert.')
    old_reference_headers = [notes.cell(1, i).value for i in range(10, 13)]
    if old_reference_headers != [None] * 3 and old_reference_headers != REFERENCE_HEADERS:
        raise ValueError('Vorhandene zusätzliche Spalten im Nachtragsblatt würden überschrieben.')
    for i, name in enumerate(REFERENCE_HEADERS, 10):
        notes.cell(1, i, name)
    existing = {}
    for n in range(2, notes.max_row + 1):
        ident = notes.cell(n, 1).value
        if not ident:
            if any(present(notes.cell(n, i).value) for i in range(2, notes.max_column + 1)):
                raise ValueError(f'Nachtragszeile {n}: Datensatz_ID fehlt; Nachtrag zuerst einem Datensatz zuordnen.')
            continue
        if ident in existing:
            raise ValueError('Doppelte Datensatz_ID im Nachtragsblatt.')
        existing[ident] = n
        notes.cell(n, 9, 'Ja' if ident in selected else 'Nein')
    if 'Importdaten' in wb:
        wb.remove(wb['Importdaten'])
    data = wb.create_sheet('Importdaten', 0)
    data.append(rows[0] + IMPORT_HEADERS)
    stats = Counter(input_filtered=filtered, retained=len(selected), removed=filtered - len(selected))
    for ident, row in selected.items():
        info = reference_info(row, reference_results, ref)
        stats[info[1]] += 1
        missing = [name for name, index in [('K', 10), ('L', 11)] if not present(row[index])]
        if missing and ident not in existing:
            notes.append([ident, row[0], row[10], row[11], '', '', 'Offen', '', 'Ja', *info])
            existing[ident] = notes.max_row
        k_value, l_value = row[10], row[11]
        k_source = 'CSV' if present(k_value) else ''
        l_source = 'CSV' if present(l_value) else ''
        if info[1] == 'Treffer':
            if not present(k_value):
                k_value, k_source = info[0], 'Referenz G'
            if not present(l_value):
                l_value, l_source = info[0], 'Referenz G'
        status, note = '', ''
        if ident in existing:
            n = existing[ident]
            for i, value in enumerate(info, 10):
                # Direkte Wertzuweisung löscht veraltete Referenzwerte auch bei Leerstring.
                notes.cell(n, i).value = value
            if present(notes.cell(n, 5).value):
                k_value, k_source = notes.cell(n, 5).value, 'Manueller Nachtrag'
            if present(notes.cell(n, 6).value):
                l_value, l_source = notes.cell(n, 6).value, 'Manueller Nachtrag'
            status, note = notes.cell(n, 7).value or '', notes.cell(n, 8).value or ''
        remaining = [name for name, value in [('K', k_value), ('L', l_value)] if not present(value)]
        reasons = ['Text fehlt in ' + ' und '.join(remaining)] if remaining else []
        if 'prüfen' in info[1] or 'Formelergebnis fehlt' in info[1]:
            reasons.append(info[1])
        stats['manual_needed'] += bool(reasons)
        stats['reference_filled_rows'] += k_source == 'Referenz G' or l_source == 'Referenz G'
        effective_row = row.copy()
        effective_row[10], effective_row[11] = k_value, l_value
        data.append(effective_row + [ident, 'Ja' if reasons else 'Nein', '; '.join(reasons), *info, k_value, l_value, status, note, row[10], row[11], k_source, l_source])
    for sheet in [data, notes]:
        sheet.freeze_panes = 'A2'
        sheet.auto_filter.ref = sheet.dimensions
        for cell in sheet[1]:
            cell.font = Font(bold=True)
        for cells in sheet:
            for cell in cells:
                if isinstance(cell.value, str):
                    if len(cell.value) > 32767:
                        raise ValueError('Text überschreitet die Excel-Zellgrenze; keine Daten werden gekürzt.')
                    # CSV und externe Ergebnisse sind Daten, keine Excel-Formeln.
                    cell.data_type = 's'
        for name in ['A', 'B', 'G', 'I']:
            sheet.column_dimensions[name].width = 22
    for col in ['C', 'D', 'E', 'F', 'H', 'J', 'K', 'L']:
        notes.column_dimensions[col].width = 35
    for r in notes.iter_rows(min_row=2):
        for cell in r:
            cell.alignment = Alignment(vertical='top', wrap_text=True)
    descriptor, temp_name = tempfile.mkstemp(prefix=target.stem + '.', suffix='.xlsx', dir=target.parent)
    os.close(descriptor)
    temp = Path(temp_name)
    try:
        if encrypted_input:
            # Die unverschlüsselte Arbeitsmappe bleibt ausschließlich im Speicher.
            updated_plaintext = io.BytesIO()
            wb.save(updated_plaintext)
            updated_plaintext.seek(0)
            with temp.open('wb') as encrypted_output:
                office_crypto.OfficeFile(updated_plaintext).encrypt(password, encrypted_output)
            verified_plaintext = io.BytesIO()
            with temp.open('rb') as encrypted_output:
                verification = office_crypto.OfficeFile(encrypted_output)
                if not verification.is_encrypted():
                    raise ValueError('Verschlüsselung der aktualisierten Datei fehlgeschlagen.')
                verification.load_key(password=password, verify_password=True)
                verification.decrypt(verified_plaintext, verify_integrity=True)
            if verified_plaintext.getvalue() != updated_plaintext.getvalue():
                raise ValueError('Prüfung der verschlüsselten Ausgabe fehlgeschlagen; Original bleibt unverändert.')
        else:
            wb.save(temp)
        temp.replace(target)
    finally:
        wb.close()
        temp.unlink(missing_ok=True)
    print(f"{stats['retained']} Importzeilen; {stats['removed']} Duplikate entfernt; "
          f"{stats['Treffer']} eindeutige Referenztreffer; "
          f"{stats['Mehrere unterschiedliche Ergebnisse – prüfen']} mit unterschiedlichen Referenzergebnissen.")
    if ref is None:
        print('Hinweis: Referenzdatei fehlt im CSV-Ordner; Fälle bleiben zur Nachbearbeitung markiert.')
    return dict(stats)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('csv_datei')
    parser.add_argument('ausgabe_xlsx')
    parser.add_argument('--referenz', help='Optionaler anderer Pfad zur Referenzdatei')
    args = parser.parse_args()
    update(args.csv_datei, args.ausgabe_xlsx, args.referenz)
