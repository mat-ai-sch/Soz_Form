# Import und dauerhafte Nachbearbeitung

## Dateien im Arbeitsordner

- `StatFormImport.csv`: jeweils aktueller Export.
- `StatBoardReakt_Neu.xlsm`: historische Ergebnisse in Spalte G.
- `Soz_Auswertung_geschuetzt.xlsx`: Auswertung mit zwei Blättern und Öffnungskennwort.
- `import_aktualisieren.py`: Import und Abgleich.

Für die aktuelle Auswertung wurde die hochgeladene Datei `Statistik_Container_2026.xlsm` verwendet. Das Skript unterstützt diesen Namen als Alternative, falls `StatBoardReakt_Neu.xlsm` nicht vorhanden ist. Sind beide vorhanden, hat `StatBoardReakt_Neu.xlsm` Vorrang. Die Referenz wird im Ordner der CSV gesucht, unabhängig vom Arbeitsverzeichnis des Skripts. Mit `--referenz` kann ein anderer Dateipfad angegeben werden.

## Aktualisieren

Die geschützte Excel-Datei direkt herunterladen und in Excel öffnen; das Kennwort aus dem Chat eingeben. Ein ZIP-Entpacker ist für diese Datei nicht erforderlich. `Import_Hilfen.zip` enthält ausschließlich Skript und Anleitung und lässt sich mit dem Windows-Entpacker öffnen.

Für die Importaktualisierung werden Python 3, openpyxl (getestet mit 3.1.5) und msoffcrypto-tool (getestet mit 6.0.0) benötigt. Einmalig, falls noch nicht installiert:

```sh
python -m pip install openpyxl==3.1.5 msoffcrypto-tool==6.0.0
```

Excel-Auswertung schließen, dann im Arbeitsordner ausführen:

```sh
python import_aktualisieren.py StatFormImport.csv Soz_Auswertung_geschuetzt.xlsx
```

Das Skript fragt bei einer verschlüsselten Ausgabedatei nach dem Kennwort; die Eingabe wird nicht angezeigt. Es entschlüsselt nur im Arbeitsspeicher und speichert die aktualisierte Datei wieder mit demselben Öffnungskennwort. Bei einem falschen Kennwort wird die bestehende Datei nicht verändert. Verschlüsselung und Integrität werden vor dem Ersetzen geprüft.

Dieselbe Ausgabedatei bei jedem Import verwenden. Eine neue Ausgabedatei enthält keine Nachträge aus der alten Datei. Vor Änderungen an der bestehenden Datei eine Sicherung aufbewahren. CSV und Referenzdatei werden nur gelesen; Excel-Makros werden nicht ausgeführt. Eine bisherige unverschlüsselte `Soz_Auswertung.xlsx` bleibt ebenfalls unterstützt; im Befehl dann ihren Dateinamen verwenden.

## Verarbeitung

1. Spalte N muss `GewuenschteUntersuchung` heißen. Nur `FSSOZKN2` und `FSSOZKN3` werden übernommen.
2. Zeilen mit gleicher Fallnummer und exakt gleichem ursprünglichem Textpaar K/L werden zusammengeführt. Bei unterschiedlichen Texten bleiben mehrere Zeilen erhalten. Diese Prüfung geschieht vor den Ergänzungen aus der Referenz.
3. Für jede Zeile mit fehlendem K oder L wird die Fallnummer in allen passenden Referenzblättern gesucht. Ein passendes Blatt hat eine Kopfzeile mit `Fallnummer` (oder `Fallnr`) und `Ergebnis` in G. In der aktuellen Referenz steht die Fallnummer in C. Nur numerische Fallnummern werden abgeglichen; Excel-Zahlen und entsprechende CSV-Zeichenketten werden gleich behandelt, auch bei führenden Nullen. Namen werden nicht als Ersatzschlüssel verwendet.
4. Ein eindeutiger, nicht leerer Text aus G füllt die jeweils leere Spalte K/L. Sind beide leer, wird G in beide übernommen. Identische historische Ergebnisse zählen als ein Ergebnis; unterschiedliche Ergebnisse werden zur Prüfung angezeigt und nicht automatisch zugeordnet.
5. Manuelle Einträge aus dem zweiten Blatt haben Vorrang. Sonst bleibt vorhandener CSV-Text erhalten, danach folgt der Ersatz aus Referenz G.

K und L im Blatt `Importdaten` enthalten die ergänzten Werte. Die zusätzlichen Spalten `Text_K_Original` und `Ueberleitung_L_Original` bewahren die CSV-Texte. `Textquelle_K`, `Textquelle_L` und `Referenz_Quelle` machen Ergänzungen nachvollziehbar. `Manuelle_Nachbearbeitung = Ja` kennzeichnet weiterhin fehlende Texte oder unklare Referenzergebnisse.

Die aktuelle Auswertung umfasst 1.815 Zeilen nach Entfernung von 1.098 Duplikaten. 819 Zeilen wurden aus eindeutigen Referenzergebnissen ergänzt. 991 haben keinen passenden Ergebnistext; bei 5 liegen unterschiedliche Ergebnisse vor. Somit bleiben 996 Zeilen zur manuellen Nachbearbeitung markiert.

## Manueller Nachtrag

Im zweiten Blatt `Manueller Nachtrag` nur diese Felder bearbeiten:

- `Nachtrag_K`
- `Nachtrag_L`
- `Bearbeitungsstatus`
- `Notiz`

Danach die Arbeitsmappe speichern und schließen. Beim nächsten Skriptlauf werden die Nachträge in K/L des ersten Blatts übernommen. Alle manuellen Inhalte und Statusangaben bleiben erhalten. Der Status allein ersetzt keine fehlenden Texte: `Erledigt` ist eine persönliche Statusangabe; die automatische Markierung wird aus den tatsächlich verfügbaren Texten abgeleitet.

`Datensatz_ID`, Fallnummer und Originaltexte nicht ändern. Die ID verbindet die Fallnummer mit dem exakten ursprünglichen Textpaar. Änderungen am Referenzergebnis G ändern die ID nicht und beeinträchtigen bestehende Nachträge nicht.

Das Nachtragsblatt enthält auch Zeilen, die jetzt durch G ergänzt werden können; vorhandene Nachtragszeilen werden nicht gelöscht. Entfällt ein Datensatz im neuen Import oder ändert sich sein ursprüngliches Textpaar, bleibt der alte Nachtrag mit `Im_aktuellen_Import = Nein` erhalten. Für einen geänderten Datensatz wird gegebenenfalls eine neue Nachtragszeile angelegt. Alte Nachträge werden bei veränderten Textvarianten nicht ungeprüft auf eine andere Zeile derselben Fallnummer übertragen.

Fehlt die Referenzdatei, funktioniert der CSV-Import weiterhin; fehlende Texte bleiben markiert und der Referenzstatus zeigt die fehlende Datei. Eine vorhandene, aber ungeeignete Referenzdatei oder fehlerhafte CSV stoppt den Lauf, bevor die bestehende Ausgabedatei überschrieben wird.

Die Ausarbeitung `SOZ_Reakt` liegt weiterhin nicht vor; die Duplikatregel beruht auf den beschriebenen Anforderungen.
