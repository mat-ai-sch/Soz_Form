"""Interne Import-Metadaten in einem XLSX-Paket, ohne zusätzliches Tabellenblatt.

Die Daten sind hier nicht verschlüsselt. Der Aufrufer muss das fertige XLSX
anschließend mit der Office-Dateiverschlüsselung schützen. openpyxl erhält
Custom-XML-Teile beim Speichern nicht: deshalb vor dem Laden read_metadata()
und nach jedem Speichern add_metadata() verwenden.
"""

import base64
import binascii
import copy
import hashlib
import io
import json
import posixpath
import zipfile
import zlib
from xml.etree import ElementTree as ET


_NS = 'urn:soz-form:statistik-metadata:v1'
_RELS_NS = 'http://schemas.openxmlformats.org/package/2006/relationships'
_CT_NS = 'http://schemas.openxmlformats.org/package/2006/content-types'
_DS_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/customXml'
_OFFICE_RELS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/'
_CUSTOM_XML = _OFFICE_RELS + 'customXml'
_CUSTOM_XML_PROPS = _OFFICE_RELS + 'customXmlProps'
_PART = 'customXml/sozMetadata.xml'
_PROPS = 'customXml/sozMetadataProps.xml'
_PART_RELS = 'customXml/_rels/sozMetadata.xml.rels'
_ITEM_ID = '{D0B63DDD-B8C8-56A9-85C2-E6B4585EE972}'
_MAX_JSON_BYTES = 64 * 1024 * 1024


def _xml(data, expected_tag):
    try:
        root = ET.fromstring(data)
    except ET.ParseError as exc:
        raise ValueError('Interne XLSX-Metadaten enthalten ungültiges XML.') from exc
    if root.tag != expected_tag:
        raise ValueError('Unerwartetes Format der internen XLSX-Metadaten.')
    return root


def _xml_bytes(root):
    # Manche Office-Bibliotheken erkennen "Types" nur ohne Präfix. Die
    # Paket-Namespaces deshalb als Default-Namespace schreiben, ohne dabei
    # ElementTrees globale Namespace-Registrierung des Aufrufers zu verändern.
    for namespace in (_CT_NS, _RELS_NS):
        prefix = '{' + namespace + '}'
        if root.tag.startswith(prefix):
            root = copy.deepcopy(root)
            for element in root.iter():
                if isinstance(element.tag, str) and element.tag.startswith(prefix):
                    element.tag = element.tag[len(prefix):]
            root.set('xmlns', namespace)
            break
    return ET.tostring(root, encoding='utf-8', xml_declaration=True)


def _target_path(folder, target):
    return posixpath.normpath(target.lstrip('/') if target.startswith('/')
                              else posixpath.join(folder, target))


def _unique_names(archive):
    names = archive.namelist()
    if len(names) != len(set(names)):
        raise ValueError('XLSX-Paket enthält doppelte Dateiteile.')
    return set(names)


def _workbook_rels(archive):
    root = _xml(archive.read('_rels/.rels'), f'{{{_RELS_NS}}}Relationships')
    office = [r for r in root if r.get('Type') in {
        _OFFICE_RELS + 'officeDocument',
        'http://purl.oclc.org/ooxml/officeDocument/relationships/officeDocument',
    }]
    if len(office) != 1 or office[0].get('TargetMode') == 'External':
        raise ValueError('Eindeutiger interner Workbook-Verweis fehlt im XLSX-Paket.')
    workbook = posixpath.normpath(office[0].get('Target', '').lstrip('/'))
    if workbook in {'', '.', '..'} or workbook.startswith('../') or workbook not in archive.namelist():
        raise ValueError('Ungültiger Workbook-Verweis im XLSX-Paket.')
    folder, name = posixpath.split(workbook)
    rels_path = posixpath.join(folder, '_rels', name + '.rels')
    if rels_path in archive.namelist():
        rels = _xml(archive.read(rels_path), f'{{{_RELS_NS}}}Relationships')
    else:
        rels = ET.Element(f'{{{_RELS_NS}}}Relationships')
    return folder, rels_path, rels


def _reject_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Doppelter Schlüssel in internen XLSX-Metadaten.')
        result[key] = value
    return result


def _invalid_constant(value):
    raise ValueError('Ungültige JSON-Zahl in internen XLSX-Metadaten.')


def _decode_metadata(data):
    root = _xml(data, f'{{{_NS}}}metadata')
    if root.get('version') != '1' or root.get('encoding') != 'zlib-base64' or len(root):
        raise ValueError('Nicht unterstützte Version interner XLSX-Metadaten.')
    try:
        compressed = base64.b64decode(root.text or '', validate=True)
        decoder = zlib.decompressobj()
        raw = decoder.decompress(compressed, _MAX_JSON_BYTES + 1)
        if len(raw) > _MAX_JSON_BYTES or not decoder.eof or decoder.unused_data:
            raise ValueError('Interne XLSX-Metadaten sind zu groß oder beschädigt.')
        if hashlib.sha256(raw).hexdigest() != root.get('sha256'):
            raise ValueError('Prüfsumme der internen XLSX-Metadaten stimmt nicht.')
        result = json.loads(
            raw.decode('utf-8'), object_pairs_hook=_reject_duplicate_keys,
            parse_constant=_invalid_constant,
        )
    except (binascii.Error, UnicodeError, zlib.error, json.JSONDecodeError) as exc:
        raise ValueError('Interne XLSX-Metadaten sind beschädigt.') from exc
    if not isinstance(result, dict):
        raise ValueError('Interne XLSX-Metadaten müssen ein JSON-Objekt sein.')
    return result


def read_metadata(xlsx_bytes):
    """Metadaten lesen; None nur bei fehlendem Teil, ValueError bei Schäden."""
    try:
        with zipfile.ZipFile(io.BytesIO(xlsx_bytes)) as archive:
            names = _unique_names(archive)
            if _PART not in names:
                if _PROPS in names or _PART_RELS in names:
                    raise ValueError('Unvollständige interne XLSX-Metadaten.')
                return None
            if not {_PROPS, _PART_RELS}.issubset(names):
                raise ValueError('Unvollständige interne XLSX-Metadaten.')
            folder, _, workbook_rels = _workbook_rels(archive)
            links = [r for r in workbook_rels if r.get('Type') == _CUSTOM_XML
                     and r.get('TargetMode') != 'External'
                     and _target_path(folder, r.get('Target', '')) == _PART]
            if len(links) != 1:
                raise ValueError('Verknüpfung der internen XLSX-Metadaten fehlt oder ist doppelt.')
            props = _xml(archive.read(_PROPS), f'{{{_DS_NS}}}datastoreItem')
            if props.get(f'{{{_DS_NS}}}itemID') != _ITEM_ID:
                raise ValueError('Unbekannte Identität der internen XLSX-Metadaten.')
            rels = _xml(archive.read(_PART_RELS), f'{{{_RELS_NS}}}Relationships')
            if len(rels) != 1 or rels[0].get('Type') != _CUSTOM_XML_PROPS or rels[0].get('Target') != posixpath.basename(_PROPS):
                raise ValueError('Ungültiger Eigenschaftsverweis der internen XLSX-Metadaten.')
            return _decode_metadata(archive.read(_PART))
    except (zipfile.BadZipFile, KeyError) as exc:
        raise ValueError('Kein gültiges unverschlüsseltes XLSX-Paket.') from exc


def add_metadata(xlsx_bytes, metadata_dict):
    """Metadaten im Speicher hinzufügen/ersetzen; übrige ZIP-Teile erhalten."""
    if not isinstance(metadata_dict, dict):
        raise ValueError('Metadaten müssen ein JSON-Objekt sein.')
    try:
        raw = json.dumps(metadata_dict, ensure_ascii=False, allow_nan=False,
                         separators=(',', ':'), sort_keys=True).encode('utf-8')
    except (TypeError, ValueError, UnicodeError) as exc:
        raise ValueError('Metadaten müssen gültige JSON-Daten enthalten.') from exc
    if len(raw) > _MAX_JSON_BYTES:
        raise ValueError('Interne XLSX-Metadaten überschreiten die Größenbegrenzung.')
    # Ein fremder oder beschädigter Teil am reservierten Pfad wird nie überschrieben.
    read_metadata(xlsx_bytes)
    metadata = ET.Element(f'{{{_NS}}}metadata', {
        'version': '1', 'encoding': 'zlib-base64',
        'sha256': hashlib.sha256(raw).hexdigest(),
    })
    metadata.text = base64.b64encode(zlib.compress(raw, 9)).decode('ascii')
    props = ET.Element(f'{{{_DS_NS}}}datastoreItem', {f'{{{_DS_NS}}}itemID': _ITEM_ID})
    schema_refs = ET.SubElement(props, f'{{{_DS_NS}}}schemaRefs')
    ET.SubElement(schema_refs, f'{{{_DS_NS}}}schemaRef', {f'{{{_DS_NS}}}uri': _NS})
    part_rels = ET.Element(f'{{{_RELS_NS}}}Relationships')
    ET.SubElement(part_rels, f'{{{_RELS_NS}}}Relationship', {
        'Id': 'rIdSozMetadataProps', 'Type': _CUSTOM_XML_PROPS,
        'Target': posixpath.basename(_PROPS),
    })
    try:
        with zipfile.ZipFile(io.BytesIO(xlsx_bytes)) as original:
            _unique_names(original)
            folder, rels_path, rels = _workbook_rels(original)
            # Vorhandene eigene Verknüpfung ersetzen, andere unverändert erhalten.
            for rel in list(rels):
                if (rel.get('Type') == _CUSTOM_XML and rel.get('TargetMode') != 'External'
                        and _target_path(folder, rel.get('Target', '')) == _PART):
                    rels.remove(rel)
            used_ids = {rel.get('Id') for rel in rels}
            ident = 'rIdSozMetadata'
            suffix = 1
            while ident in used_ids:
                ident = 'rIdSozMetadata' + str(suffix)
                suffix += 1
            ET.SubElement(rels, f'{{{_RELS_NS}}}Relationship', {
                'Id': ident, 'Type': _CUSTOM_XML,
                'Target': posixpath.relpath(_PART, folder or '.'),
            })
            content_types = _xml(original.read('[Content_Types].xml'), f'{{{_CT_NS}}}Types')
            for part, mime in [
                (_PART, 'application/xml'),
                (_PROPS, 'application/vnd.openxmlformats-officedocument.customXmlProperties+xml'),
            ]:
                for entry in list(content_types):
                    if entry.tag == f'{{{_CT_NS}}}Override' and entry.get('PartName') == '/' + part:
                        content_types.remove(entry)
                ET.SubElement(content_types, f'{{{_CT_NS}}}Override', {
                    'PartName': '/' + part, 'ContentType': mime,
                })
            replacements = {
                _PART: _xml_bytes(metadata), _PROPS: _xml_bytes(props),
                _PART_RELS: _xml_bytes(part_rels),
                rels_path: _xml_bytes(rels),
                '[Content_Types].xml': _xml_bytes(content_types),
            }
            output = io.BytesIO()
            with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED) as updated:
                updated.comment = original.comment
                for item in original.infolist():
                    data = (replacements.pop(item.filename) if item.filename in replacements
                            else original.read(item.filename))
                    updated.writestr(item, data)
                for name, data in replacements.items():
                    updated.writestr(name, data)
            result = output.getvalue()
    except (zipfile.BadZipFile, KeyError) as exc:
        raise ValueError('Kein gültiges unverschlüsseltes XLSX-Paket.') from exc
    if read_metadata(result) != json.loads(raw):
        raise ValueError('Prüfung der gespeicherten internen XLSX-Metadaten fehlgeschlagen.')
    return result
