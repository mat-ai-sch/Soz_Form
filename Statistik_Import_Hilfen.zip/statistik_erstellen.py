"""Drei Statistikblätter erzeugen und vorhandene manuelle Nachträge erhalten.

python statistik_erstellen.py StatFormImport.csv Statistik_Container_2026.xlsm Soz_Statistik_geschuetzt.xlsx
Das Öffnungskennwort wird verdeckt abgefragt. Benötigt openpyxl und msoffcrypto-tool.
"""
import argparse
import csv
import getpass
import hashlib
import io
import json
import math
import os
import posixpath
import re
import tempfile
import zipfile
from collections import Counter, defaultdict
from copy import copy
from datetime import date, datetime
from pathlib import Path
from zoneinfo import ZoneInfo
from xml.etree import ElementTree as ET

import msoffcrypto
from openpyxl import Workbook, load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter, coordinate_to_tuple
from statistik_metadata import add_metadata, read_metadata

HEADERS = ['Fallnummer', 'Alter', 'Wohnort', 'Aufnahmedatum', 'Entlassdatum',
           'Fachabteilung', 'Ergebnis', 'KZP-Potenzial', 'Wohin?', 'Alloheim', 'Verbund', 'Notiz']
CODES = {'FSSOZKN2', 'FSSOZKN3'}


def present(value):
    return value is not None and bool(str(value).strip())


def validate(value):
    if isinstance(value, str) and len(value) > 32767:
        raise ValueError('Text überschreitet die Excel-Zellgrenze; die Ausgabe wird nicht verändert.')


def case_id(value):
    if value is None or isinstance(value, bool):
        return ''
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer():
            return ''
        return str(int(value))
    value = str(value).strip()
    if re.fullmatch(r'[0-9]+(?:\.0+)?', value):
        return str(int(value.split('.')[0]))
    return value


def packed(value):
    if isinstance(value, datetime):
        return {'_date': value.isoformat()}
    if isinstance(value, date):
        return {'_date': datetime.combine(value, datetime.min.time()).isoformat()}
    # Excel speichert leere Zeichenketten beim erneuten Lesen als None.
    return None if value == '' else value


def unpacked(value):
    if isinstance(value, dict) and '_date' in value:
        return datetime.fromisoformat(value['_date'])
    return value


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def parse_date(value):
    if not present(value):
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, date):
        return datetime.combine(value, datetime.min.time())
    for fmt in ['%d.%m.%Y', '%d.%m.%Y %H:%M', '%d.%m.%Y %H:%M:%S', '%Y-%m-%d']:
        try:
            return datetime.strptime(str(value).strip(), fmt)
        except ValueError:
            pass
    raise ValueError('Ein Geburts-, Aufnahme- oder Entlassdatum ist nicht lesbar.')


def age_at(birth, when):
    if birth is None or when is None:
        return None
    b, w = birth.date(), when.date() if isinstance(when, datetime) else when
    if b > w:
        raise ValueError('Ein Geburtsdatum liegt nach dem Bezugsdatum.')
    return w.year - b.year - ((w.month, w.day) < (b.month, b.day))


def decrypt_bytes(path, password):
    with Path(path).open('rb') as source:
        office = msoffcrypto.OfficeFile(source)
        if not office.is_encrypted():
            raise ValueError('Die bestehende Ausgabedatei ist nicht im erwarteten verschlüsselten Format.')
        office.load_key(password=password, verify_password=True)
        result = io.BytesIO()
        office.decrypt(result, verify_integrity=True)
        return result.getvalue()


def read_previous(target, password):
    if not target.exists():
        return {}, {}
    data = decrypt_bytes(target, password)
    metadata = read_metadata(data)
    if not metadata or metadata.get('version') != 1:
        raise ValueError('Importzuordnung der bestehenden Datei fehlt. Zur Sicherheit wird sie nicht überschrieben.')
    wb = load_workbook(io.BytesIO(data))
    try:
        sheet = wb['Stat_Komb']
        if [c.value for c in sheet[1]] != HEADERS:
            raise ValueError('Die Spalten von Stat_Komb wurden verändert.')
        known = metadata['rows']
        overrides = metadata.get('overrides', {})
        seen = set()
        for cells in sheet.iter_rows(min_row=2):
            if not any(present(c.value) for c in cells):
                continue
            note = cells[0].comment.text if cells[0].comment else ''
            match = re.search(r'Import-ID: ([a-f0-9]{64})', note)
            if not match or match[1] not in known or match[1] in seen:
                raise ValueError('Importzuordnung in Stat_Komb fehlt oder ist doppelt; nichts überschrieben.')
            ident = match[1]
            seen.add(ident)
            base = known[ident]
            if case_id(cells[0].value) != base['case']:
                raise ValueError('Eine Fallnummer in Stat_Komb wurde geändert; nichts überschrieben.')
            for i in range(6, 12):
                current = packed(cells[i].value)
                if current != base['display'][i]:
                    overrides.setdefault(ident, {'case': base['case'], 'values': {}})['values'][str(i)] = current
        return known, overrides
    finally:
        wb.close()


def copy_raw_reference(source, target):
    target.cell(1, 1, 'Originalblätter aus Statistik_Container_2026.xlsm, unverändert untereinander')
    target.cell(1, 16, 'Herkunft_Blatt')
    target.cell(1, 17, 'Herkunft_Zeile')
    positions = {}
    offset = 1
    for sheet in source:
        start = offset + 1
        for row in sheet:
            for cell in row:
                validate(cell.value)
                out = target.cell(offset + cell.row, cell.column, cell.value)
                out.data_type = cell.data_type
                if cell.has_style:
                    out.font = copy(cell.font)
                    out.fill = copy(cell.fill)
                    out.border = copy(cell.border)
                    out.alignment = copy(cell.alignment)
                    out.protection = copy(cell.protection)
                    out.number_format = cell.number_format
                if cell.comment:
                    out.comment = copy(cell.comment)
            number = row[0].row
            positions[(sheet.title, number)] = offset + number
            target.cell(offset + number, 16, sheet.title)
            target.cell(offset + number, 17, number)
            if sheet.row_dimensions[number].height:
                target.row_dimensions[offset + number].height = sheet.row_dimensions[number].height
        for merged in sheet.merged_cells.ranges:
            target.merge_cells(start_row=merged.min_row + offset, end_row=merged.max_row + offset,
                               start_column=merged.min_col, end_column=merged.max_col)
        target.row_dimensions.group(start, offset + sheet.max_row, hidden=False)
        offset += sheet.max_row + 1
    target.freeze_panes = 'A2'
    for i in range(1, 18):
        target.column_dimensions[get_column_letter(i)].width = 22 if i not in [2, 7, 15, 16] else 38
    return positions


def preserve_raw_numbers(xlsx_bytes, source_path, source, positions):
    """Numerische Originalwerte ohne erneute Dezimalrundung übernehmen."""
    main = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    docrels = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
    pkg = 'http://schemas.openxmlformats.org/package/2006/relationships'
    with zipfile.ZipFile(source_path) as original, zipfile.ZipFile(io.BytesIO(xlsx_bytes)) as output:
        workbook = ET.fromstring(original.read('xl/workbook.xml'))
        relationships = ET.fromstring(original.read('xl/_rels/workbook.xml.rels'))
        targets = {rel.get('Id'): rel.get('Target') for rel in relationships.findall(f'{{{pkg}}}Relationship')}
        part = 'xl/worksheets/sheet2.xml'
        raw_sheet = ET.fromstring(output.read(part))
        cells = {cell.get('r'): cell for cell in raw_sheet.iter(f'{{{main}}}c')}
        for sheet in workbook.find(f'{{{main}}}sheets'):
            name = sheet.get('name')
            target = targets[sheet.get(f'{{{docrels}}}id')]
            path = target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join('xl', target))
            for cell in ET.fromstring(original.read(path)).iter(f'{{{main}}}c'):
                value = cell.find(f'{{{main}}}v')
                if cell.get('t', 'n') != 'n' or value is None:
                    continue
                row, column = coordinate_to_tuple(cell.get('r'))
                original_cell = source[name].cell(row, column)
                if original_cell.is_date or original_cell.value is None:
                    continue
                dest = cells.get(f'{get_column_letter(column)}{positions[(name, row)]}')
                if dest is not None:
                    numeric = dest.find(f'{{{main}}}v')
                    if numeric is not None:
                        numeric.text = value.text
        patched = io.BytesIO()
        with zipfile.ZipFile(patched, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
            for info in output.infolist():
                archive.writestr(info, ET.tostring(raw_sheet, encoding='utf-8', xml_declaration=True)
                                 if info.filename == part else output.read(info.filename))
        return patched.getvalue()


def consolidate_reference(entries):
    """Eine Container-Zuordnung pro Fall, mit erster ausgefüllter Angabe je Feld."""
    first = entries[0]
    row = first['row'].copy()
    fields, conflicts = {}, []
    for column in [6, 7, 8, 11, 12, 13, 14]:
        available = [entry for entry in entries if present(entry['row'][column])]
        if available:
            fields[column] = available[0]
            row[column] = available[0]['row'][column]
            if len({digest(packed(entry['row'][column])) for entry in available}) > 1:
                conflicts.append(column)
    return {**first, 'row': row, 'field_sources': fields,
            'conflict_columns': conflicts, 'sources': entries}


def retain_case_overrides(prepared, overrides):
    """Alte Textvarianten eindeutig auf die neue Fall-Zuordnung übertragen."""
    by_case = defaultdict(list)
    for ident, entry in overrides.items():
        by_case[entry['case']].append(ident)
    for entry in prepared:
        ident = entry['id']
        if ident in overrides:
            continue
        previous = by_case.get(entry['case'], [])
        merged = {}
        for old_id in previous:
            for column, value in overrides[old_id]['values'].items():
                if column in merged and merged[column] != value:
                    raise ValueError('Zu einer Fallnummer liegen widersprüchliche manuelle Nachträge vor. '
                                     'Diese zuerst vereinheitlichen; die bestehende Datei bleibt unverändert.')
                merged[column] = value
        if previous:
            overrides[ident] = {'case': entry['case'], 'values': merged}
            for old_id in previous:
                overrides[old_id]['migrated_to'] = ident


def generate(csv_path, ref_path, target, password, age_mode='aufnahme', filter_codes=True, as_of=None):
    csv_path, ref_path, target = Path(csv_path), Path(ref_path), Path(target)
    if target.suffix.lower() != '.xlsx' or target.resolve() in {csv_path.resolve(), ref_path.resolve()}:
        raise ValueError('Eine separate XLSX-Ausgabedatei angeben.')
    if not password:
        raise ValueError('Ein Öffnungskennwort ist erforderlich.')
    if age_mode not in {'aufnahme', 'heute'}:
        raise ValueError('Unbekannter Altersbezug.')
    if filter_codes is not True:
        raise ValueError('Der Filter auf FSSOZKN2/FSSOZKN3 ist zwingend erforderlich.')
    as_of = as_of or datetime.now(ZoneInfo('Europe/Berlin')).date()
    old_rows, overrides = read_previous(target, password)
    try:
        text = csv_path.read_bytes().decode('utf-8-sig')
    except UnicodeDecodeError:
        text = csv_path.read_bytes().decode('cp1252')
    csv_rows = list(csv.reader(io.StringIO(text, newline=''), delimiter=';'))
    expected = {0:'Fallnummer', 3:'Geburtsdatum', 4:'Ort', 5:'Aufnahmedatum', 6:'Entlassdatum',
                7:'Fachabteilung', 9:'KZP-Potenzial', 10:'Text', 11:'Ueberleitung', 13:'GewuenschteUntersuchung'}
    if not csv_rows or any(len(csv_rows[0]) <= i or csv_rows[0][i] != name for i, name in expected.items()):
        raise ValueError('Die CSV-Kopfzeile stimmt nicht mit dem erwarteten Export überein.')
    # Erst auswählen, dann auf Fallnummer reduzieren. Spätere oder nicht
    # ausgewählte CSV-Zeilen liefern keinerlei Daten für die Verarbeitung.
    filtered_rows = [(number, row) for number, row in enumerate(csv_rows[1:], 2)
                     if len(row) > 13 and row[13] in CODES]
    for _, row in filtered_rows:
        if len(row) != len(csv_rows[0]):
            raise ValueError('Eine CSV-Zeile hat eine abweichende Spaltenzahl.')
        for value in row:
            validate(value)
    ref = load_workbook(ref_path, data_only=False)
    ref_by_case, groups = defaultdict(list), {}
    filtered = len(filtered_rows)
    try:
        for number, row in filtered_rows:
            case = case_id(row[0])
            if not case.isdigit():
                raise ValueError('Einer ausgewählten CSV-Zeile fehlt eine numerische Fallnummer.')
            if case not in groups:
                groups[case] = {'case': case, 'form': row,
                                'form_row': len(groups) + 2, 'csv_source_row': number}
        compatible = 0
        for sheet in ref:
            header = [c.value for c in sheet[1]]
            if len(header) < 15 or header[2] != 'Fallnummer' or header[6] != 'Ergebnis':
                continue
            if [header[i] for i in [7, 11, 12, 13, 14]] != ['Wohin?', 'KZP-Potenzial', 'Alloheim', 'Verbund', 'Notiz']:
                raise ValueError('Spalten der Containerdatei entsprechen nicht der erwarteten Struktur.')
            compatible += 1
            for cells in sheet.iter_rows(min_row=2):
                row = [c.value for c in cells]
                case = case_id(row[2])
                if case.isdigit():
                    for cell in cells:
                        validate(cell.value)
                        if cell.data_type == 'f':
                            raise ValueError('Container-Falldaten enthalten Formeln; zuerst als berechnete Werte bereitstellen.')
                    ref_by_case[case].append({'row': row, 'sheet': sheet.title, 'number': cells[0].row})
        if not compatible:
            raise ValueError('Die Containerdatei hat kein passendes Fallblatt.')
        selected_cases = set(groups)
        prepared_form_rows = [group['form'] for group in groups.values()]
        reference_cases = {case: consolidate_reference(entries) for case, entries in ref_by_case.items()}
        for case in ref_by_case:
            if case not in selected_cases:
                groups[case] = {'case': case, 'form': None, 'form_row': None, 'csv_source_row': None}
        wb = Workbook()
        wb.remove(wb.active)
        form_sheet, cont_sheet, combined = [wb.create_sheet(n) for n in ['Stat_Form', 'Stat_Cont', 'Stat_Komb']]
        for number, row in enumerate([csv_rows[0], *prepared_form_rows], 1):
            form_sheet.append(row)
            for column in range(1, len(row) + 1):
                form_sheet.cell(number, column).data_type = 's'
        form_sheet.freeze_panes = 'A2'
        form_sheet.auto_filter.ref = form_sheet.dimensions
        positions = copy_raw_reference(ref, cont_sheet)
        combined.append(HEADERS)
        prepared = []
        for case, group in groups.items():
            form = group.get('form')
            demographics = form
            if demographics:
                birth = parse_date(demographics[3])
                admission, discharge = parse_date(demographics[5]), parse_date(demographics[6])
                age = age_at(birth, admission if age_mode == 'aufnahme' else as_of)
                location, department = demographics[4], demographics[7]
            else:
                birth = admission = discharge = age = None
                location = department = None
            csv_texts = list(dict.fromkeys(v for v in [form[10], form[11]] if present(v))) if form else []
            csv_result = '\n'.join(csv_texts)
            csv_kzp = form[9] if form else None
            entry = reference_cases.get(case)
            r = entry['row'] if entry else [None] * 15
            result = csv_result if present(csv_result) else r[6]
            kzp = r[11] if present(r[11]) else csv_kzp
            place = location if present(location) else r[8]
            values = [form[0] if form else case, age, place, admission, discharge,
                      department, result, kzp, r[7], r[12], r[13], r[14]]
            for value in values:
                validate(value)
            prepared.append({'values': values, 'sources': entry['sources'] if entry else [], 'ref': entry,
                             'id': digest(['case', case]), 'case': case, 'form_row': group.get('form_row'),
                             'csv_source_row': group.get('csv_source_row'),
                             'csv_result': bool(csv_result), 'csv_kzp': csv_kzp})
        if len(prepared) != len({entry['case'] for entry in prepared}):
            raise ValueError('Die Zusammenführung enthält unerwartete Fallduplikate.')
        retain_case_overrides(prepared, overrides)
        metadata = {'version': 1, 'rows': {}, 'overrides': overrides,
                    'age_mode': age_mode, 'filter_codes': True, 'case_policy': 'first_filtered_unique',
                    'as_of': as_of.isoformat()}
        manual_cells = 0
        for number, entry in enumerate(prepared, 2):
            values = entry['values'].copy()
            override = overrides.get(entry['id'], {}).get('values', {})
            for i, value in override.items():
                values[int(i)] = unpacked(value)
                validate(values[int(i)])
            combined.append(values)
            sources = [f"{s['sheet']}!Zeile {s['number']}" for s in entry['sources']]
            origin = (f"Stat_Form!Zeile {entry['form_row']} (CSV-Originalzeile {entry['csv_source_row']})"
                      if entry['form_row'] else 'Nur Container')
            note = f"Quelle: {origin}" + ('; Container: ' + '; '.join(sources) if sources else '')
            if entry['ref'] and entry['ref']['conflict_columns']:
                columns = ', '.join(get_column_letter(i + 1) for i in entry['ref']['conflict_columns'])
                note += f'\nContainer hat unterschiedliche Werte in {columns}; erster ausgefüllter Wert je Feld verwendet.'
            combined.cell(number, 1).comment = Comment(note + '\nImport-ID: ' + entry['id'], 'Statistikimport')
            if entry['form_row']:
                combined.cell(number, 1).hyperlink = f"#'Stat_Form'!A{entry['form_row']}"
            elif entry['ref']:
                position = positions[(entry['ref']['sheet'], entry['ref']['number'])]
                combined.cell(number, 1).hyperlink = f"#'Stat_Cont'!C{position}"
            for i in range(12):
                cell = combined.cell(number, i + 1)
                if isinstance(cell.value, str):
                    cell.data_type = 's'
                cell.alignment = Alignment(vertical='top', wrap_text=True)
                if i in [3, 4] or isinstance(cell.value, datetime):
                    cell.number_format = 'DD.MM.YYYY'
                if i >= 6:
                    if str(i) in override:
                        cell.fill = PatternFill('solid', fgColor='DDEBF7')
                        cell.comment = Comment('Manueller Nachtrag erhalten.\n' + note, 'Statistikimport')
                        manual_cells += 1
                    elif not present(cell.value) and i == 6:
                        cell.fill = PatternFill('solid', fgColor='FFF2CC')
                        cell.comment = Comment('Ergebnis fehlt – manuell nachbearbeiten.\n' + note, 'Statistikimport')
                    else:
                        provenance = 'Stat_Form (Text/Ueberleitung haben Vorrang)' if i == 6 and entry['csv_result'] else 'Stat_Cont' if i >= 8 or (i == 7 and entry['ref'] and present(entry['ref']['row'][11])) or (i == 6 and entry['sources']) else 'Stat_Form'
                        cell.comment = Comment('Quelle: ' + provenance + '\n' + note, 'Statistikimport')
            metadata['rows'][entry['id']] = {'case': entry['case'], 'display': [packed(v) for v in values],
                                           'csv_source_row': entry['csv_source_row']}
        for sheet in [form_sheet, combined]:
            for cell in sheet[1]:
                cell.font = Font(bold=True, color='FFFFFF')
                cell.fill = PatternFill('solid', fgColor='24476A')
                cell.alignment = Alignment(wrap_text=True, vertical='top')
            sheet.row_dimensions[1].height = 32
            for i in range(1, sheet.max_column + 1):
                sheet.column_dimensions[get_column_letter(i)].width = 20
        for c in ['K', 'L']:
            form_sheet.column_dimensions[c].width = 48
        combined.column_dimensions['B'].width = 10
        combined.column_dimensions['G'].width = 65
        combined.column_dimensions['L'].width = 45
        combined.freeze_panes = 'A2'
        combined.auto_filter.ref = combined.dimensions
        wb.active = 2
        buffer = io.BytesIO()
        wb.save(buffer)
        wb.close()
        plain = add_metadata(preserve_raw_numbers(buffer.getvalue(), ref_path, ref, positions), metadata)
        encrypted = io.BytesIO()
        msoffcrypto.OfficeFile(io.BytesIO(plain)).encrypt(password, encrypted)
        verification = msoffcrypto.OfficeFile(io.BytesIO(encrypted.getvalue()))
        verification.load_key(password=password, verify_password=True)
        decrypted = io.BytesIO()
        verification.decrypt(decrypted, verify_integrity=True)
        if decrypted.getvalue() != plain:
            raise ValueError('Die verschlüsselte Ausgabe besteht die Integritätsprüfung nicht.')
        fd, name = tempfile.mkstemp(prefix=target.stem + '.', suffix='.xlsx', dir=target.parent)
        os.close(fd)
        temporary = Path(name)
        try:
            temporary.write_bytes(encrypted.getvalue())
            temporary.replace(target)
        finally:
            temporary.unlink(missing_ok=True)
        stats = {'csv_original': len(csv_rows) - 1, 'csv_filtered': filtered,
                 'csv_deduplicated': sum(1 for g in groups.values() if g.get('form') is not None),
                 'csv_duplicates_removed': filtered - len(prepared_form_rows),
                 'container_original_rows': sum(s.max_row for s in ref),
                 'container_cases_with_conflicts': sum(bool(r['conflict_columns']) for r in reference_cases.values()),
                 'combined_rows': len(prepared), 'combined_cases': len({r['case'] for r in prepared}),
                 'reference_only_cases': len(set(ref_by_case) - selected_cases),
                 'missing_result': sum(not present(r['display'][6]) for r in metadata['rows'].values()),
                 'manual_cells': manual_cells}
        print(json.dumps(stats, ensure_ascii=False))
        return stats
    finally:
        ref.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('csv_datei')
    parser.add_argument('container_datei')
    parser.add_argument('ausgabe_xlsx')
    args = parser.parse_args()
    generate(args.csv_datei, args.container_datei, args.ausgabe_xlsx,
             password=getpass.getpass('Öffnungskennwort der Excel-Datei: '))
