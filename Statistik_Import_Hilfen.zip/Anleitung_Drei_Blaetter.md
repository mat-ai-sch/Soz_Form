# Statistik mit drei Tabellenblättern

Die neue Arbeitsmappe heißt `Soz_Statistik_geschuetzt.xlsx`. Sie ist mit einem Excel-Öffnungskennwort geschützt und kann direkt in Excel geöffnet werden. Das Kennwort steht ausschließlich im Chat.

## Stat_Form

Vollständige Originaldaten aus `StatFormImport.csv`: sämtliche Zeilen, alle 15 Spalten und die ursprüngliche Reihenfolge. Die bisherige Untersuchungsauswahl wird ausschließlich auf die Zusammenführung angewendet.

## Stat_Cont

Sämtliche sieben Originalblätter aus `Statistik_Container_2026.xlsm` sind untereinander übernommen, einschließlich der Monatskopfzeilen, Leerzeilen und der Übersicht `Q1 Einrichtungen`. Die Originalspalten bleiben an ihren Positionen. Die zusätzlichen Spalten P und Q nennen Quellblatt und ursprüngliche Zeilennummer. Sie dienen der Nachvollziehbarkeit und gehören nicht zur Auswertung.

## Stat_Komb

| Spalte | Inhalt | Zuordnung |
| --- | --- | --- |
| A | Fallnummer | Gemeinsamer Schlüssel beider Quellen |
| B | Alter | Vollendete Lebensjahre am Aufnahmedatum, berechnet aus CSV-Geburtsdatum |
| C | Wohnort | CSV `Ort`, ersatzweise Container `Wohnort` |
| D | Aufnahmedatum | CSV `Aufnahmedatum` |
| E | Entlassdatum | CSV `Entlassdatum` |
| F | Fachabteilung | CSV `Fachabteilung` |
| G | Ergebnis | CSV `Text` und `Ueberleitung`, unterschiedliche Texte mit Zeilenumbruch verbunden. Nur wenn beide leer sind, Container `Ergebnis` |
| H | KZP-Potenzial | Vorhandener Containerwert aus L hat Vorrang vor CSV `KZP-Potenzial`; ein leerer Containerwert löscht keinen vorhandenen CSV-Wert |
| I | Wohin? | Container H |
| J | Alloheim | Container M |
| K | Verbund | Container N |
| L | Notiz | Container O |

Für CSV-Fälle gilt weiterhin ausschließlich `FSSOZKN2` bzw. `FSSOZKN3` in Spalte N. Gleiche Fallnummern mit exakt gleichem ursprünglichem Textpaar K/L werden zusammengeführt; die sonstigen CSV-Angaben stammen deterministisch aus der ersten zugehörigen Originalzeile. Bei unterschiedlichen Textpaaren bleiben die Zeilen getrennt.

Zusätzlich werden numerische Container-Fälle aufgenommen, die nicht in dieser CSV-Auswahl vorkommen. Falls ihre Fallnummer in anderen CSV-Zeilen vorkommt, werden deren demografische Angaben verwendet, nicht deren ausgeschlossene Untersuchungstexte. Fehlen Geburts- oder Aufnahmedatum, bleibt das Alter leer. Das Containerfeld `Datum` wird nicht als Aufnahmedatum ausgegeben.

Wiederholte Containerzeilen werden nur zusammengeführt, wenn sie für die erzeugte Zeile dieselben Werte ergeben. Unterschiedliche zusammengehörige Ergebnisse, KZP-Werte, Ziele oder Notizen bleiben als getrennte Varianten erhalten. Es werden keine voneinander unabhängigen Containerfelder zu erfundenen Kombinationen vermischt.

Fehlende Ergebnisse sind gelb markiert. Kommentare und Verknüpfungen an der Fallnummer zeigen die Herkunft. Originaltexte und Quellwerte bleiben in den ersten beiden Blättern erhalten. Unterschiedliche Ergebnistexte werden nicht automatisch in Kategorien umgedeutet.

## Import aktualisieren

Excel speichern und schließen. CSV, Containerdatei und die bestehende Ausgabedatei im Arbeitsordner ablegen. Beide Python-Dateien aus `Statistik_Import_Hilfen.zip` zusammen entpacken und im selben Ordner belassen.

Einmalig die benötigten Bibliotheken installieren:

```sh
python -m pip install openpyxl==3.1.5 msoffcrypto-tool==6.0.0 tzdata
```

Anschließend ausführen:

```sh
python statistik_erstellen.py StatFormImport.csv Statistik_Container_2026.xlsm Soz_Statistik_geschuetzt.xlsx
```

Das Kennwort wird verdeckt abgefragt. Es wird weder im Skript noch in der Anleitung gespeichert. Die Auswertung bleibt bei Aktualisierungen mit demselben Kennwort verschlüsselt. CSV und Containerdatei werden nur gelesen. Ein falsches Kennwort oder eine fehlerhafte Quelle verändert die bestehende Ausgabedatei nicht.

Die Zusammenführung und das Alter werden beim Skriptlauf berechnet. Änderungen an einem Originalblatt innerhalb der Auswertung ersetzen daher nicht die Aktualisierung der Quelldateien.

## Manuelle Nachbearbeitung

Manuelle Ergänzungen direkt in den Spalten G–L von `Stat_Komb` vornehmen und die Datei speichern. Diese Einträge haben beim nächsten Import Vorrang und werden blau markiert. Das Skript vergleicht Änderungen mit dem zuletzt gespeicherten Ausgabestand.

Für diese Zuordnung die Kommentare an der Fallnummer und die internen Importinformationen erhalten. Das Blatt `Stat_Komb` nicht durch eine Kopie ohne Kommentare ersetzen. Fehlt die Zuordnung, bricht das Skript ab, statt bestehende Bearbeitungen ungeprüft zu überschreiben.

Nachträge zu vorübergehend weggefallenen Fällen bleiben intern erhalten und werden bei identisch wiederkehrenden Datensätzen wieder übernommen. Bei eindeutigem Quellenwechsel kann ein Nachtrag auch einer neuen Einzelzeile derselben Fallnummer zugeordnet werden. Bei mehreren veränderten Varianten erfolgt keine unsichere Übertragung; der bisherige Nachtrag bleibt intern gespeichert. Im Arbeitsordner stets dieselbe Ausgabedatei weiterverwenden und vor Änderungen eine Sicherung aufbewahren.

Die bisherige Auswertung `Soz_Auswertung_geschuetzt.xlsx` wird durch dieses Skript nicht überschrieben. Für das neue Drei-Blatt-Schema ist `Soz_Statistik_geschuetzt.xlsx` vorgesehen.
