# Statistik mit drei Tabellenblättern

Die neue Arbeitsmappe heißt `Soz_Statistik_geschuetzt.xlsx`. Sie ist mit einem Excel-Öffnungskennwort geschützt und kann direkt in Excel geöffnet werden. Das Kennwort steht ausschließlich im Chat.

## Stat_Form

Die CSV wird zwingend vor jeder Weiterverarbeitung vorbereitet:

1. Nur Zeilen mit `FSSOZKN2` oder `FSSOZKN3` in Spalte N auswählen.
2. Danach je Fallnummer ausschließlich die erste ausgewählte Zeile in der ursprünglichen Dateireihenfolge behalten.
3. Nur diese Zeilen nach `Stat_Form` übernehmen und für die Zusammenführung verwenden.

Alle 15 Spalten der behaltenen Originalzeilen bleiben erhalten. Die Quelldatei selbst wird nicht verändert. Spätere CSV-Duplikate werden unabhängig von abweichenden Texten oder sonstigen Angaben vollständig verworfen; ausgeschlossene Untersuchungen liefern ebenfalls keine Angaben. Aus 2.913 ausgewählten Zeilen entstehen aktuell 1.811 Fälle; 1.102 spätere Duplikate entfallen.

## Stat_Cont

Sämtliche sieben Originalblätter aus `Statistik_Container_2026.xlsm` sind untereinander übernommen, einschließlich der Monatskopfzeilen, Leerzeilen und der Übersicht `Q1 Einrichtungen`. Die Originalspalten bleiben an ihren Positionen. Die zusätzlichen Spalten P und Q nennen Quellblatt und ursprüngliche Zeilennummer. Sie dienen der Nachvollziehbarkeit und gehören nicht zur Auswertung.

## Stat_Komb

| Spalte | Inhalt | Zuordnung |
| --- | --- | --- |
| A | Fallnummer | Gemeinsamer Schlüssel beider Quellen |
| B | Alter | Vollendete Lebensjahre am Aufnahmedatum, berechnet aus CSV-Geburtsdatum |
| C | Wohnort | CSV `Ort`, ersatzweise Container `Wohnort` |
| D | Aufnahmedatum | CSV `Aufnahmedatum` |
| E | Entlassdatum | CSV `Entlassdatum` |
| F | Fachabteilung | CSV `Fachabteilung` |
| G | Ergebnis | CSV `Text` und `Ueberleitung`, unterschiedliche Texte mit Zeilenumbruch verbunden. Nur wenn beide leer sind, Container `Ergebnis` |
| H | KZP-Potenzial | Vorhandener Containerwert aus L hat Vorrang vor CSV `KZP-Potenzial`; ein leerer Containerwert löscht keinen vorhandenen CSV-Wert |
| I | Wohin? | Container H |
| J | Alloheim | Container M |
| K | Verbund | Container N |
| L | Notiz | Container O |

`Stat_Komb` enthält jede Fallnummer genau einmal. Es verwendet ausschließlich die in `Stat_Form` enthaltenen vorbereiteten CSV-Zeilen. Die frühere Ausnahme für unterschiedliche K/L-Texte entfällt.

Zusätzlich werden numerische Container-Fälle aufgenommen, die nicht in dieser CSV-Auswahl vorkommen. Es werden keine Angaben aus ausgeschlossenen oder später verworfenen CSV-Zeilen ergänzt. Fehlen Geburts- oder Aufnahmedatum, bleibt das Alter leer. Das Containerfeld `Datum` wird nicht als Aufnahmedatum ausgegeben.

Mehrere Containerzeilen derselben Fallnummer erzeugen keine zusätzlichen Ergebniszeilen. Je benötigtem Containerfeld wird der erste ausgefüllte Wert in der Reihenfolge der Quellblätter und Quellzeilen verwendet. Ist ein Feld zunächst leer, kann eine spätere Containerzeile es ergänzen. Unterschiedliche spätere Werte ersetzen einen bereits gefundenen Wert nicht; entsprechende Quellenkonflikte werden an der Fallnummer kommentiert. Sämtliche Container-Originalzeilen bleiben im Blatt `Stat_Cont` nachvollziehbar.

Die aktuelle Zusammenführung umfasst 1.881 eindeutige Fälle: 1.811 vorbereitete CSV-Fälle und 70 zusätzliche Containerfälle. 179 Fälle haben weiterhin keinen Ergebnistext in den zulässigen Quellen.

Fehlende Ergebnisse sind gelb markiert. Kommentare und Verknüpfungen an der Fallnummer zeigen die Herkunft. Originaltexte und Quellwerte bleiben in den ersten beiden Blättern erhalten. Unterschiedliche Ergebnistexte werden nicht automatisch in Kategorien umgedeutet.

## Import aktualisieren

Excel speichern und schließen. CSV, Containerdatei und die bestehende Ausgabedatei im Arbeitsordner ablegen. Beide Python-Dateien aus `Statistik_Import_Hilfen.zip` zusammen entpacken und im selben Ordner belassen.

Einmalig die benötigten Bibliotheken installieren:

```sh
python -m pip install openpyxl==3.1.5 msoffcrypto-tool==6.0.0 tzdata
```

Anschließend ausführen:

```sh
python statistik_erstellen.py StatFormImport.csv Statistik_Container_2026.xlsm Soz_Statistik_geschuetzt.xlsx
```

Das Kennwort wird verdeckt abgefragt. Es wird weder im Skript noch in der Anleitung gespeichert. Die Auswertung bleibt bei Aktualisierungen mit demselben Kennwort verschlüsselt. CSV und Containerdatei werden nur gelesen. Ein falsches Kennwort oder eine fehlerhafte Quelle verändert die bestehende Ausgabedatei nicht.

Die Zusammenführung und das Alter werden beim Skriptlauf berechnet. Änderungen an einem Originalblatt innerhalb der Auswertung ersetzen daher nicht die Aktualisierung der Quelldateien.

## Manuelle Nachbearbeitung

Manuelle Ergänzungen direkt in den Spalten G–L von `Stat_Komb` vornehmen und die Datei speichern. Diese Einträge haben beim nächsten Import Vorrang und werden blau markiert. Das Skript vergleicht Änderungen mit dem zuletzt gespeicherten Ausgabestand.

Für diese Zuordnung die Kommentare an der Fallnummer und die internen Importinformationen erhalten. Das Blatt `Stat_Komb` nicht durch eine Kopie ohne Kommentare ersetzen. Fehlt die Zuordnung, bricht das Skript ab, statt bestehende Bearbeitungen ungeprüft zu überschreiben.

Nachträge werden eindeutig an der Fallnummer gespeichert. Sie bleiben auch bei Änderungen der importierten Texte erhalten. Nachträge zu vorübergehend weggefallenen Fällen bleiben intern erhalten und werden beim Wiederauftauchen übernommen.

Nachträge aus der bisherigen Fassung mit mehreren Zeilen je Fall werden zusammengeführt, wenn sie sich nicht widersprechen. Unterschiedliche manuelle Werte für dasselbe Feld derselben Fallnummer führen zum Abbruch, damit keine Bearbeitung ungeprüft verloren geht. Bereits übertragene ältere Nachträge bleiben intern archiviert; aktuelle Nachträge haben bei weiteren Aktualisierungen Vorrang. Im Arbeitsordner stets dieselbe Ausgabedatei weiterverwenden und vor Änderungen eine Sicherung aufbewahren.

Die bisherige Auswertung `Soz_Auswertung_geschuetzt.xlsx` wird durch dieses Skript nicht überschrieben. Für das neue Drei-Blatt-Schema ist `Soz_Statistik_geschuetzt.xlsx` vorgesehen.
